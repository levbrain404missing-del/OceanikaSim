from pioneer_sdk2 import Camera, ImageViewer          # импортируем классы Camera и ImageViewer из библиотеки pioneer_sdk2

camera = Camera()                                      # создаем экземпляр класса Camera
viewer = ImageViewer()                                 # создаем экземпляр класса ImageViewer

try:                                                    # основной код находится внутри блока try
    while True:                                         # запускаем бесконечный цикл
        frame = camera.get_cv_frame(timeout=5.0)        # сохраняем изображение в переменную frame
                                                        # timeout=5.0 - время ожидания кадра в секундах

        if frame is not None:                           # проверяем, что изображение получено
            viewer.imshow("video", frame, fps=30)       # отправляем изображение в RTSP-трансляцию

except KeyboardInterrupt:                               # если пользователь остановил программу сочетанием Ctrl+C
    print("Остановка программы")                        # выводим сообщение об остановке программы

finally:                                                # блок finally выполнится при завершении программы
    viewer.close()                                      # останавливаем RTSP-трансляцию
    camera.stop()                                       # закрываем передачу кадров
