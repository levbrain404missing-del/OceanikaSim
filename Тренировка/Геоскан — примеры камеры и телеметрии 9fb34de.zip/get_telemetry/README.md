### 📌 Демонстрационные примеры `get_telemetry`

#### 💡 **Описание**

Скрипты в этой папке читают отдельные группы телеметрии через методы класса `Pioneer`.
Все примеры работают в цикле и закрывают соединение с дроном при остановке программы.

## 🧩 **Компоненты**

- `get_accel.py` — ускорение по осям X, Y, Z.
- `get_altitude.py` — высота.
- `get_battery_status.py` — напряжение и температура аккумулятора.
- `get_dist_sensor.py` — данные дальномера.
- `get_global_position_gps.py` — GPS-координаты.
- `get_global_velocity.py` — скорость по GPS.
- `get_local_position.py` — локальная позиция LPS.
- `get_local_velocity_lps.py` — локальная скорость LPS.
- `get_local_yaw_lps.py` — курс LPS.
- `get_mag.py` — магнитометр.
- `get_motors_rpm.py` — обороты двигателей.
- `get_nav_status_gps.py` — статус GPS-навигации.
- `get_nav_status_lps.py` — статус LPS-навигации.
- `get_nav_system.py` — активная система навигации.
- `get_optical_data.py` — данные оптической навигации.
- `get_orientation.py` — roll, pitch, yaw.
- `get_satellites_count.py` — количество спутников GPS и ГЛОНАСС.

## 📚 **Пример запуска**

```bash
python3 get_battery_status.py
```

## 📈 **Технические особенности**

- Если датчик или навигационный модуль недоступен, пример выводит сообщение вместо падения с ошибкой.
- `get_motors_rpm.py` запускает моторы командой `arm()` и выключает их в `finally`.
- Для остановки циклических примеров используйте `Ctrl+C`.
