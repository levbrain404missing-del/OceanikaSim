from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        distance = drone.get_dist_sensor_data() # получаем данные с дальномера
        print(f'Расстояние: {distance:.2f} м') # выводим расстояние в консоль
        time.sleep(1)                          # ставим паузу на 1 секунду

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение