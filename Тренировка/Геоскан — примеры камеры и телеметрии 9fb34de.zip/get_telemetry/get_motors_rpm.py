from pioneer_sdk2 import Pioneer            # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                                 # библиотека time содержит функции для работы со временем

drone = Pioneer()                           # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                        # основной код находится внутри блока try
    while True:                             # запускаем бесконечный цикл
        motors_rpm = drone.get_motors_rpm() # получаем обороты двигателей
        print(
            f"motor_1={motors_rpm[0]},",    # обороты первого двигателя
            f"motor_2={motors_rpm[1]},",    # обороты второго двигателя
            f"motor_3={motors_rpm[2]},",    # обороты третьего двигателя
            f"motor_4={motors_rpm[3]}"      # обороты четвертого двигателя
        )

        time.sleep(0.5)                     # ставим паузу на 0.5 секунды

finally:                                    # блок finally выполнится при завершении программы
    drone.close_connection()                # закрываем соединение