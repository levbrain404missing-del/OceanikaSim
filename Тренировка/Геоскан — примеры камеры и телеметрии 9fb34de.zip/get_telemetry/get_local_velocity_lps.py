from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        local_velocity = drone.get_local_velocity_lps() # получаем текущую скорость дрона

        print(
            f"vx={local_velocity[0]},", # скорость по оси X
            f"vy={local_velocity[1]},", # скорость по оси Y
            f"vz={local_velocity[2]}"   # скорость по оси Z
        )                               # выводим текущую скорость в терминал

        time.sleep(1)                   # ставим паузу на 1 секунду

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение