from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        # получаем текущие координаты дрона в метрах
        array_of_coordinates = drone.get_local_position_lps()

        # выводим координаты x, y, z в консоль
        print(f'x={array_of_coordinates[0]} , y={array_of_coordinates[1]}, z={array_of_coordinates[2]}')

        # print(f'x={array_of_coordinates[0]}') # пример вывода координаты x отдельно

        time.sleep(1)                   # ставим паузу на 1 секунду

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение
