from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        gps_position = drone.get_global_position_gps() # получаем GPS координаты дрона

        print(
            f"latitude={gps_position[0]},",  # широта
            f"longitude={gps_position[1]},", # долгота
            f"altitude={gps_position[2]}"    # высота
        )                                    # выводим GPS координаты в терминал

        time.sleep(1)                        # ставим паузу на 1 секунду

finally:                                     # блок finally выполнится при завершении программы
    drone.close_connection()                 # закрываем соединение