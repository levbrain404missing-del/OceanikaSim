from pioneer_sdk2 import Pioneer # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                      # библиотека time содержит функции для работы со временем

drone = Pioneer()                # создаем экземпляр класса Pioneer, устанавливаем соединение

print(drone.get_nav_system())    # выводим активную систему навигации в терминал
                                 # NavSystem.GPS
                                 # NavSystem.LPS
                                 # NavSystem.OPT

drone.close_connection()         # закрываем соединение