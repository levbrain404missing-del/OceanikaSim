from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        optical_data = drone.get_optical_data() # получаем данные оптического потока
        print(optical_data)                     # выводим данные в терминал
        time.sleep(0.5)                         # ставим паузу на 0.5 секунды

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение
