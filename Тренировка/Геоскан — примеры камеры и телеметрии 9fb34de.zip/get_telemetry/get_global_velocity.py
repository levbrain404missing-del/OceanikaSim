from pioneer_sdk2 import Pioneer         # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                              # библиотека time содержит функции для работы со временем

drone = Pioneer()                        # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                     # основной код находится внутри блока try
    while True:                          # запускаем бесконечный цикл
        global_velocity = drone.get_global_velocity_gps() # получаем текущую скорость по GPS

        print(
            f"vx={global_velocity[0]},", # скорость по оси X
            f"vy={global_velocity[1]},", # скорость по оси Y
            f"vz={global_velocity[2]}"   # скорость по оси Z
        )                                # выводим текущую скорость по GPS в терминал

        time.sleep(1)                    # ставим паузу на 1 секунду

finally:                                 # блок finally выполнится при завершении программы
    drone.close_connection()             # закрываем соединение