from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        mag = drone.get_mag()           # получаем данные с магнитометра
        print(
            f"mag_x={mag[0]},",         # магнитное поле по оси X
            f"mag_y={mag[1]},",         # магнитное поле по оси Y
            f"mag_z={mag[2]}",          # магнитное поле по оси Z
        )
        time.sleep(0.5)                 # ставим паузу на 0.5 секунды

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение