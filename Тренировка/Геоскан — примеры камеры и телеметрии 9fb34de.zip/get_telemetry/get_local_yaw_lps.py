from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        yaw = drone.get_local_yaw_lps() # получаем текущий угол поворота по курсу
        print(f"yaw={yaw}")             # выводим текущий угол в терминал
        time.sleep(1)                   # ставим паузу на 1 секунду

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение