from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        accel = drone.get_accel()       # получаем ускорение дрона

        print(
            f"accel_x={accel[0]},",     # ускорение по оси X
            f"accel_y={accel[1]},",     # ускорение по оси Y
            f"accel_z={accel[2]}"       # ускорение по оси Z
        )

        time.sleep(0.5)                 # ставим паузу на 0.5 секунды

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение