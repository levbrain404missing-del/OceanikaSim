from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        satellites_count = drone.get_satellites_count() # получаем количество спутников

        print(
            f"GPS={satellites_count[0]},",     # количество спутников GPS
            f"GLONASS={satellites_count[1]}"   # количество спутников ГЛОНАСС
        )                                      # выводим количество спутников в терминал

        time.sleep(1)                          # ставим паузу на 1 секунду

finally:                                       # блок finally выполнится при завершении программы
    drone.close_connection()                   # закрываем соединение