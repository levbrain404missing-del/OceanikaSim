from pioneer_sdk2 import Pioneer        # импортируем класс Pioneer из библиотеки pioneer_sdk2
import time                             # библиотека time содержит функции для работы со временем

drone = Pioneer()                       # создаем экземпляр класса Pioneer, устанавливаем соединение

try:                                    # основной код находится внутри блока try
    while True:                         # запускаем бесконечный цикл
        nav_status = drone.get_nav_status_lps() # получаем состояние LPS навигации

        print(nav_status)               # выводим состояние LPS навигации в терминал
                                        # NavStatus.NO_DATA - нет данных с LPS модуля
                                        # NavStatus.CANNOT  - невозможно оценить позицию
                                        # NavStatus.LOW     - низкое доверие к оценке позиции
                                        # NavStatus.OK      - позиция определена

        time.sleep(1)                   # ставим паузу на 1 секунду

finally:                                # блок finally выполнится при завершении программы
    drone.close_connection()            # закрываем соединение